# Edunovaa Workspace — Day 1 Foundation

A front-end only customer & service management workspace.
No backend, no API, no build step — all data comes from JavaScript objects.

## Run it

**Option 1 — just open it**
Double-click `index.html`. It works directly in Chrome, Edge or Firefox.

**Option 2 — local server (recommended)**
```bash
# from inside the edunovaa.workspace folder
npx serve .
# or
python -m http.server 5500
```
Then open http://localhost:5500 (or the port shown). With VS Code you can also use the *Live Server* extension.

## Demo login

| Email                | Password    |
|----------------------|-------------|
| admin@edunovaa.com   | Admin@123   |

The login page also has a **Use demo** button that fills these in.

## What's included (Day 1 scope)

1. **Login screen** — `index.html`
   - Email + password fields, login button
   - Basic validation: required fields, email format, min 6-char password, wrong-credential message
   - Show/hide password, "Keep me signed in", loading state
   - No backend: session stored in `sessionStorage` (or `localStorage` when "Keep me signed in" is ticked)
   - Protected pages redirect to login when signed out

2. **Dashboard** — `dashboard.html`
   - Sidebar navigation (collapses to a slide-out menu on mobile)
   - Top header: global customer search, notifications, profile menu with sign out
   - 4 summary cards: Total Customers, Active Services, Pending Requests, Revenue (all calculated from mock data)
   - Recent service requests table (click a row to open that customer)
   - Request status and customers-by-service breakdowns

3. **Customer page** — `customers.html`
   - Customer list table
   - Search by name, company, email, phone, city or ID
   - Filter by status (All / Active / Pending / Inactive) with live counts
   - Add Customer button → modal form with validation
   - Customer details in a modal: contact info, billing, service requests, notes
   - Empty states and deep links (`customers.html?id=CUS-1001`, `?q=delhi`, `?new=1`)

4. **Mock data** — `assets/js/data.js`
   - Customers, services and service requests stored as JS objects
   - Newly added customers are kept in `localStorage` so they survive a refresh
   - To reset: run `Store.resetDemoData()` in the browser console, then reload

## Folder structure

```
edunovaa.workspace/
├── index.html            Login screen
├── dashboard.html        Dashboard
├── customers.html        Customer page
├── README.md
└── assets/
    ├── css/
    │   ├── base.css      Design tokens, buttons, inputs, badges, modal, toast
    │   ├── login.css     Login screen styles
    │   └── app.css       App shell (sidebar, header), cards, tables, responsive rules
    └── js/
        ├── data.js       Mock data + tiny data store
        ├── utils.js      Icons, formatters (₹, dates), badges, toast, modal helper
        ├── auth.js       Front-end login / logout / route guard
        ├── layout.js     Renders sidebar + top header on every app page
        ├── login.js      Login page logic & validation
        ├── dashboard.js  Summary cards, requests table, breakdowns
        └── customers.js  List, search, filter, add customer, details modal
```

## Tech notes

- Plain HTML, CSS and vanilla JavaScript (ES2020). No frameworks or dependencies.
- Font: Plus Jakarta Sans from Google Fonts, with system-font fallback when offline.
- Icons are inline SVG — no icon library needed.
- Responsive down to mobile widths; keyboard accessible (focus rings, Esc closes modals, Enter opens table rows).
- Currency is formatted in Indian style (₹1,85,000 / ₹15.08 L).

## Next steps (not in Day 1)

Service requests page, services catalogue, invoices, reports, edit/delete customer, and a real backend + API.
