/* ==========================================================
   Edunovaa Workspace — Front-end only authentication
   No backend: credentials are checked against a demo account
   and the session is kept in browser storage.
   ========================================================== */
const Auth = (() => {
  const KEY = "ew_session";
  const DEMO_USER = {
    email: "admin@edunovaa.com",
    password: "Admin@123",
    name: "Mohit Raj",
    role: "Administrator"
  };

  function read() {
    try {
      return JSON.parse(sessionStorage.getItem(KEY) || localStorage.getItem(KEY) || "null");
    } catch (e) { return null; }
  }

  return {
    DEMO_USER,

    /** Returns { ok: true } or { ok: false, message } */
    login(email, password, remember) {
      const e = String(email).trim().toLowerCase();
      if (e !== DEMO_USER.email || password !== DEMO_USER.password) {
        return { ok: false, message: "The email or password is incorrect. Check both and try again." };
      }
      const session = { name: DEMO_USER.name, email: DEMO_USER.email, role: DEMO_USER.role, signedInAt: Date.now() };
      try {
        (remember ? localStorage : sessionStorage).setItem(KEY, JSON.stringify(session));
      } catch (err) { /* storage blocked — session lasts for this page only */ }
      return { ok: true };
    },

    current() { return read(); },

    logout() {
      try { sessionStorage.removeItem(KEY); localStorage.removeItem(KEY); } catch (e) {}
      window.location.replace("index.html");
    },

    /** Call at the top of every protected page */
    requireAuth() {
      if (!read()) window.location.replace("index.html");
    },

    /** Call on the login page: skip it if already signed in */
    redirectIfSignedIn() {
      if (read()) window.location.replace("dashboard.html");
    }
  };
})();
