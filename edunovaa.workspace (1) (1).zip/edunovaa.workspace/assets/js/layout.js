/* ==========================================================
   Edunovaa Workspace — Shared layout (sidebar + top header)
   Usage: Layout.render({ active: "dashboard" | "customers" })
   ========================================================== */
const Layout = (() => {
  const NAV = [
    {
      title: "Workspace",
      items: [
        { id: "dashboard", label: "Dashboard", icon: "dashboard", href: "dashboard.html" },
        { id: "customers", label: "Customers", icon: "users",     href: "customers.html", count: () => Store.getCustomers().length }
      ]
    },
    {
      title: "Coming next",
      items: [
        { id: "requests", label: "Requests", icon: "inbox",     soon: true },
        { id: "services", label: "Services",         icon: "briefcase", soon: true },
        { id: "invoices", label: "Invoices",         icon: "receipt",   soon: true },
        { id: "reports",  label: "Reports",          icon: "chart",     soon: true }
      ]
    }
  ];

  function sidebarHTML(active, user) {
    const groups = NAV.map(g => `
      <div class="nav-group">
        <div class="nav-title">${g.title}</div>
        ${g.items.map(item => item.soon
          ? `<span class="nav-item disabled" title="Planned for a later release">${ICONS[item.icon]}<span>${item.label}</span><span class="soon">Soon</span></span>`
          : `<a href="${item.href}" class="${item.id === active ? "active" : ""}" ${item.id === active ? 'aria-current="page"' : ""}>
               ${ICONS[item.icon]}<span>${item.label}</span>
               ${item.count ? `<span class="count">${item.count()}</span>` : ""}
             </a>`
        ).join("")}
      </div>`).join("");

    return `
      <div class="brand">
        <div class="brand-mark">E</div>
        <div>
          <div class="brand-name">Edunovaa</div>
          <div class="brand-sub">Workspace</div>
        </div>
      </div>
      <nav class="nav" aria-label="Main">${groups}</nav>
      <div class="sidebar-user">
        <div class="avatar avatar-sm" style="background:${avatarColor(user.name)}">${initials(user.name)}</div>
        <div class="who">
          <div class="name">${escapeHTML(user.name)}</div>
          <div class="role">${escapeHTML(user.role)}</div>
        </div>
        <button class="icon-btn" id="sidebarLogout" title="Sign out" aria-label="Sign out">${ICONS.logout}</button>
      </div>`;
  }

  function topbarHTML(user) {
    return `
      <button class="icon-btn menu-btn" id="menuBtn" aria-label="Open menu">${ICONS.menu}</button>
      <form class="global-search" id="globalSearch" role="search">
        ${ICONS.search}
        <label for="globalSearchInput" class="sr-only">Search customers</label>
        <input class="input" id="globalSearchInput" type="search" placeholder="Search customers by name, company or email" autocomplete="off">
      </form>
      <div class="topbar-actions">
        <button class="icon-btn" title="Help" aria-label="Help">${ICONS.help}</button>
        <button class="icon-btn" title="Notifications" aria-label="Notifications, 3 new">${ICONS.bell}<span class="dot"></span></button>
        <div class="user-menu">
          <button class="user-trigger" id="userTrigger" aria-haspopup="true" aria-expanded="false">
            <div class="avatar avatar-sm" style="background:${avatarColor(user.name)}">${initials(user.name)}</div>
            <span class="name">${escapeHTML(user.name)}</span>
            ${ICONS.chevronDown}
          </button>
          <div class="dropdown" id="userDropdown" role="menu">
            <div class="head"><strong>${escapeHTML(user.name)}</strong><span>${escapeHTML(user.email)}</span></div>
            <button role="menuitem" type="button">${ICONS.user} My profile</button>
            <button role="menuitem" type="button">${ICONS.settings} Settings</button>
            <button role="menuitem" type="button" class="danger" id="menuLogout">${ICONS.logout} Sign out</button>
          </div>
        </div>
      </div>`;
  }

  function bind() {
    const sidebar = document.getElementById("sidebar");
    const scrim = document.getElementById("scrim");
    const toggleSidebar = (open) => {
      sidebar.classList.toggle("open", open);
      scrim.classList.toggle("open", open);
    };
    document.getElementById("menuBtn").addEventListener("click", () => toggleSidebar(true));
    scrim.addEventListener("click", () => toggleSidebar(false));

    const trigger = document.getElementById("userTrigger");
    const dropdown = document.getElementById("userDropdown");
    trigger.addEventListener("click", (e) => {
      e.stopPropagation();
      const open = !dropdown.classList.contains("open");
      dropdown.classList.toggle("open", open);
      trigger.setAttribute("aria-expanded", String(open));
    });
    document.addEventListener("click", () => {
      dropdown.classList.remove("open");
      trigger.setAttribute("aria-expanded", "false");
    });

    document.getElementById("menuLogout").addEventListener("click", Auth.logout);
    document.getElementById("sidebarLogout").addEventListener("click", Auth.logout);

    document.getElementById("globalSearch").addEventListener("submit", (e) => {
      e.preventDefault();
      const q = document.getElementById("globalSearchInput").value.trim();
      if (typeof window.onGlobalSearch === "function") { window.onGlobalSearch(q); return; }
      window.location.href = "customers.html" + (q ? "?q=" + encodeURIComponent(q) : "");
    });
  }

  return {
    render({ active }) {
      Auth.requireAuth();
      const user = Auth.current() || { name: "Guest", role: "", email: "" };
      document.getElementById("sidebar").innerHTML = sidebarHTML(active, user);
      document.getElementById("topbar").innerHTML = topbarHTML(user);
      bind();
      Modal.init();
      return user;
    },
    refreshCounts() {
      const user = Auth.current();
      const active = document.querySelector(".nav a.active")?.getAttribute("href")?.replace(".html", "");
      document.getElementById("sidebar").innerHTML = sidebarHTML(active, user);
      document.getElementById("sidebarLogout").addEventListener("click", Auth.logout);
    }
  };
})();
