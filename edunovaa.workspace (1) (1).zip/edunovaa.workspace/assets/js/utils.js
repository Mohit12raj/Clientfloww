/* ==========================================================
   Edunovaa Workspace — Shared helpers
   ========================================================== */

/* ---------- Icons (inline SVG, no external library) ---------- */
const ICONS = (() => {
  const s = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  return {
    dashboard: s('<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>'),
    users: s('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'),
    inbox: s('<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>'),
    briefcase: s('<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/><path d="M2 13h20"/>'),
    receipt: s('<path d="M4 2v20l3-2 3 2 3-2 3 2 3-2 1 .67V2l-1 .67L16 2l-3 2-3-2-3 2z"/><path d="M8 8h8M8 12h8M8 16h5"/>'),
    chart: s('<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>'),
    settings: s('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>'),
    search: s('<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>'),
    bell: s('<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>'),
    help: s('<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>'),
    menu: s('<path d="M4 6h16M4 12h16M4 18h16"/>'),
    chevronDown: s('<path d="m6 9 6 6 6-6"/>'),
    logout: s('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>'),
    user: s('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
    plus: s('<path d="M12 5v14M5 12h14"/>'),
    x: s('<path d="M18 6 6 18M6 6l12 12"/>'),
    check: s('<path d="M20 6 9 17l-5-5"/>'),
    checkCircle: s('<circle cx="12" cy="12" r="10"/><path d="m8 12 3 3 5-6"/>'),
    alert: s('<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>'),
    eye: s('<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
    eyeOff: s('<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.4 10.4 0 0 1 12 5c6.5 0 10 7 10 7a13.2 13.2 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.5 13.5 0 0 0 2 12s3.5 7 10 7a9.7 9.7 0 0 0 5.39-1.61"/><path d="m2 2 20 20"/>'),
    activity: s('<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>'),
    clock: s('<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>'),
    rupee: s('<path d="M6 3h12M6 8h12M6 13l8.5 8M6 13h3a5 5 0 0 0 0-10"/>'),
    download: s('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>'),
    mail: s('<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>'),
    phone: s('<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.08 4.18 2 2 0 0 1 4.06 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.1 9.9a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>')
  };
})();

/* ---------- Formatters ---------- */
const fmt = {
  inr(n) {
    return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n || 0);
  },
  inrCompact(n) {
    if (n >= 10000000) return "₹" + (n / 10000000).toFixed(2).replace(/\.?0+$/, "") + " Cr";
    if (n >= 100000)   return "₹" + (n / 100000).toFixed(2).replace(/\.?0+$/, "") + " L";
    return fmt.inr(n);
  },
  date(iso) {
    if (!iso) return "—";
    const d = new Date(iso + "T00:00:00");
    return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
  },
  number(n) { return new Intl.NumberFormat("en-IN").format(n || 0); }
};

function initials(name = "") {
  return name.trim().split(/\s+/).slice(0, 2).map(p => p[0] || "").join("").toUpperCase() || "?";
}

/* Stable avatar colour per name */
function avatarColor(name = "") {
  const palette = ["#3056D3", "#1F8A5B", "#6B4FC8", "#B7791F", "#C93A3A", "#0E7C86", "#2A3C5C", "#A23B72"];
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return palette[h % palette.length];
}

function escapeHTML(str) {
  return String(str ?? "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}

/* ---------- Status badges ---------- */
function customerBadge(status) {
  const map = { Active: "badge-green", Pending: "badge-amber", Inactive: "badge-slate" };
  return `<span class="badge ${map[status] || "badge-slate"}">${escapeHTML(status)}</span>`;
}
function requestBadge(status) {
  const map = { Pending: "badge-amber", "In progress": "badge-blue", Completed: "badge-green", Cancelled: "badge-slate" };
  return `<span class="badge ${map[status] || "badge-slate"}">${escapeHTML(status)}</span>`;
}
function priorityBadge(p) {
  const map = { High: "badge-red", Medium: "badge-violet", Low: "badge-slate" };
  return `<span class="badge ${map[p] || "badge-slate"}">${escapeHTML(p)}</span>`;
}

/* ---------- Toast ---------- */
function toast(message) {
  let stack = document.querySelector(".toast-stack");
  if (!stack) {
    stack = document.createElement("div");
    stack.className = "toast-stack";
    stack.setAttribute("role", "status");
    stack.setAttribute("aria-live", "polite");
    document.body.appendChild(stack);
  }
  const el = document.createElement("div");
  el.className = "toast";
  el.innerHTML = ICONS.checkCircle + `<span>${escapeHTML(message)}</span>`;
  stack.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

/* ---------- Modal ---------- */
const Modal = {
  lastFocus: null,
  open(id) {
    const el = document.getElementById(id);
    if (!el) return;
    this.lastFocus = document.activeElement;
    el.classList.add("open");
    document.body.style.overflow = "hidden";
    const first = el.querySelector("input, select, textarea, button:not([data-close])") || el.querySelector("button");
    setTimeout(() => first && first.focus(), 30);
  },
  close(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove("open");
    if (!document.querySelector(".modal-backdrop.open")) document.body.style.overflow = "";
    if (this.lastFocus) this.lastFocus.focus();
  },
  init() {
    document.addEventListener("click", (e) => {
      const closer = e.target.closest("[data-close]");
      if (closer) { this.close(closer.closest(".modal-backdrop").id); return; }
      if (e.target.classList.contains("modal-backdrop")) this.close(e.target.id);
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        const open = document.querySelectorAll(".modal-backdrop.open");
        if (open.length) this.close(open[open.length - 1].id);
      }
    });
  }
};

function getQueryParam(key) {
  return new URLSearchParams(window.location.search).get(key);
}
