/* ==========================================================
   Edunovaa Workspace — Dashboard
   ========================================================== */
(function () {
  const user = Layout.render({ active: "dashboard" });

  const customers = Store.getCustomers();
  const requests  = Store.getRequests();
  const now = new Date();

  /* ---------- Header ---------- */
  const hour = now.getHours();
  const greet = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  document.getElementById("greeting").textContent = `${greet}, ${user.name.split(" ")[0]}`;
  document.getElementById("today").textContent =
    "Here's how things stand on " + now.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) + ".";
  document.getElementById("newCustomerBtn").innerHTML = ICONS.plus + "Add customer";

  /* ---------- Summary cards ---------- */
  const thisMonth = now.toISOString().slice(0, 7);
  const joinedThisMonth = customers.filter(c => (c.joinedOn || "").startsWith(thisMonth)).length;

  const activeCustomers = customers.filter(c => c.status === "Active");
  const serviceLines = new Set(activeCustomers.map(c => c.service)).size;

  const pending = requests.filter(r => r.status === "Pending");
  const pendingHigh = pending.filter(r => r.priority === "High").length;

  const revenue = customers.reduce((sum, c) => sum + (Number(c.totalBilled) || 0), 0);

  const cards = [
    {
      label: "Total Customers", value: fmt.number(customers.length), icon: "users", tone: "tone-blue",
      note: joinedThisMonth ? `<span class="up">+${joinedThisMonth}</span> joined this month` : "No new customers this month"
    },
    {
      label: "Active Services", value: fmt.number(activeCustomers.length), icon: "activity", tone: "tone-green",
      note: `Across ${serviceLines} service line${serviceLines === 1 ? "" : "s"}`
    },
    {
      label: "Pending Requests", value: fmt.number(pending.length), icon: "clock", tone: "tone-amber",
      note: pendingHigh ? `<span class="warn">${pendingHigh} high priority</span> need attention` : "Nothing urgent"
    },
    {
      label: "Revenue", value: fmt.inrCompact(revenue), icon: "rupee", tone: "tone-violet",
      note: `${fmt.inr(revenue)} billed to date`
    }
  ];

  document.getElementById("stats").innerHTML = cards.map(c => `
    <article class="stat">
      <div class="stat-top">
        <span class="stat-label">${c.label}</span>
        <span class="stat-icon ${c.tone}">${ICONS[c.icon]}</span>
      </div>
      <div class="stat-value">${c.value}</div>
      <div class="stat-note">${c.note}</div>
    </article>`).join("");

  /* ---------- Recent service requests table ---------- */
  const byId = Object.fromEntries(customers.map(c => [c.id, c]));
  const recent = requests
    .slice()
    .sort((a, b) => b.requestedOn.localeCompare(a.requestedOn))
    .slice(0, 8);

  document.getElementById("requestsBody").innerHTML = recent.map(r => {
    const c = byId[r.customerId] || { name: "Unknown", company: "" };
    return `
      <tr class="clickable" data-customer="${r.customerId}" tabindex="0" aria-label="Open ${escapeHTML(c.name)}">
        <td>
          <div class="cell-person" style="gap:0;flex-direction:column;align-items:flex-start">
            <span class="t">${escapeHTML(r.title)}</span>
            <span class="s"><span class="mono-id">${r.id}</span><span style="margin-left:8px">${escapeHTML(r.service)}</span></span>
          </div>
        </td>
        <td>
          <div class="cell-person">
            <div class="avatar avatar-sm" style="background:${avatarColor(c.name)}">${initials(c.name)}</div>
            <div><div class="t">${escapeHTML(c.name)}</div><div class="s">${escapeHTML(c.company)}</div></div>
          </div>
        </td>
        <td class="cell-muted">${fmt.date(r.requestedOn)}</td>
        <td>${priorityBadge(r.priority)}</td>
        <td>${requestBadge(r.status)}</td>
        <td class="right num" style="font-weight:600">${r.amount ? fmt.inr(r.amount) : "—"}</td>
      </tr>`;
  }).join("");

  const openCustomer = (row) => window.location.href = "customers.html?id=" + encodeURIComponent(row.dataset.customer);
  document.getElementById("requestsBody").addEventListener("click", (e) => {
    const row = e.target.closest("tr[data-customer]");
    if (row) openCustomer(row);
  });
  document.getElementById("requestsBody").addEventListener("keydown", (e) => {
    const row = e.target.closest("tr[data-customer]");
    if (row && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); openCustomer(row); }
  });

  /* ---------- Breakdowns ---------- */
  const statusColors = { Pending: "var(--amber-600)", "In progress": "var(--blue-600)", Completed: "var(--green-600)", Cancelled: "var(--slate-600)" };
  const statusCounts = ["Pending", "In progress", "Completed", "Cancelled"].map(s => ({ label: s, n: requests.filter(r => r.status === s).length }));
  document.getElementById("requestTotal").textContent = `${requests.length} requests in total`;
  document.getElementById("statusBreakdown").innerHTML = statusCounts.map(s => bar(s.label, s.n, requests.length, statusColors[s.label])).join("");

  const serviceCounts = SERVICES
    .map(s => ({ label: s, n: activeCustomers.filter(c => c.service === s).length }))
    .filter(s => s.n > 0)
    .sort((a, b) => b.n - a.n);
  document.getElementById("serviceBreakdown").innerHTML = serviceCounts.length
    ? serviceCounts.map(s => bar(s.label, s.n, activeCustomers.length, "var(--navy-700)")).join("")
    : `<p style="color:var(--muted);font-size:13px">No active customers yet.</p>`;

  function bar(label, n, total, color) {
    const pct = total ? Math.round((n / total) * 100) : 0;
    return `
      <div class="breakdown-row">
        <div class="top"><span>${escapeHTML(label)}</span><span>${n}</span></div>
        <div class="bar" role="img" aria-label="${escapeHTML(label)}: ${n} of ${total}"><i style="width:${pct}%;background:${color}"></i></div>
      </div>`;
  }
})();
