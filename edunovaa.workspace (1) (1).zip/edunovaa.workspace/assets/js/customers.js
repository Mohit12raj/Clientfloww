/* ==========================================================
   Edunovaa Workspace — Customers page
   List, search, filter by status, add customer, view details.
   ========================================================== */
(function () {
  Layout.render({ active: "customers" });

  const state = {
    query: getQueryParam("q") || "",
    status: "All"
  };

  const body        = document.getElementById("customerBody");
  const emptyState  = document.getElementById("emptyState");
  const resultCount = document.getElementById("resultCount");
  const searchInput = document.getElementById("searchInput");
  const filterEl    = document.getElementById("statusFilter");

  /* ---------- Static bits ---------- */
  document.getElementById("searchIcon").innerHTML = ICONS.search;
  document.getElementById("addCustomerBtn").innerHTML = ICONS.plus + "Add customer";
  document.getElementById("addClose").innerHTML = ICONS.x;
  document.getElementById("detailClose").innerHTML = ICONS.x;
  document.getElementById("f-service").innerHTML =
    `<option value="">Select a service</option>` + SERVICES.map(s => `<option>${s}</option>`).join("");
  document.getElementById("f-status").innerHTML = CUSTOMER_STATUSES.map(s => `<option>${s}</option>`).join("");
  searchInput.value = state.query;
  const globalInput = document.getElementById("globalSearchInput");
  if (globalInput) globalInput.value = state.query;

  /* ---------- Filtering ---------- */
  function matches(c, q) {
    if (!q) return true;
    const hay = [c.name, c.company, c.email, c.phone, c.city, c.id, c.service].join(" ").toLowerCase();
    return q.toLowerCase().split(/\s+/).every(term => hay.includes(term));
  }

  function renderFilters(searchMatched) {
    const options = ["All", ...CUSTOMER_STATUSES];
    filterEl.innerHTML = options.map(s => {
      const n = s === "All" ? searchMatched.length : searchMatched.filter(c => c.status === s).length;
      const active = state.status === s;
      return `<button type="button" data-status="${s}" class="${active ? "active" : ""}" aria-pressed="${active}">${s}<span class="n">${n}</span></button>`;
    }).join("");
  }

  function render() {
    const all = Store.getCustomers();
    const searchMatched = all.filter(c => matches(c, state.query));
    const list = state.status === "All" ? searchMatched : searchMatched.filter(c => c.status === state.status);

    renderFilters(searchMatched);
    resultCount.textContent = `Showing ${list.length} of ${all.length} customers`;

    if (!list.length) {
      body.innerHTML = "";
      emptyState.hidden = false;
      const filtered = state.query || state.status !== "All";
      emptyState.innerHTML = `
        <div class="empty">
          <div class="ico">${filtered ? ICONS.search : ICONS.users}</div>
          <h3>${filtered ? "No customers match these filters" : "No customers yet"}</h3>
          <p>${filtered ? "Try a different search term or choose another status." : "Add your first customer to start tracking their services."}</p>
          ${filtered
            ? `<button class="btn btn-secondary" type="button" id="clearFilters">Clear filters</button>`
            : `<button class="btn btn-primary" type="button" id="emptyAdd">${ICONS.plus}Add customer</button>`}
        </div>`;
      document.getElementById("clearFilters")?.addEventListener("click", () => {
        state.query = ""; state.status = "All"; searchInput.value = ""; render();
      });
      document.getElementById("emptyAdd")?.addEventListener("click", openAdd);
      return;
    }

    emptyState.hidden = true;
    body.innerHTML = list.map(c => `
      <tr class="clickable" data-id="${c.id}" tabindex="0" aria-label="View details for ${escapeHTML(c.name)}">
        <td>
          <div class="cell-person">
            <div class="avatar" style="background:${avatarColor(c.name)}">${initials(c.name)}</div>
            <div>
              <div class="t">${escapeHTML(c.name)}</div>
              <div class="s">${escapeHTML(c.company)}${c.city ? `, ${escapeHTML(c.city)}` : ""}</div>
            </div>
          </div>
        </td>
        <td>
          <div class="cell-person" style="flex-direction:column;align-items:flex-start;gap:0">
            <span class="cell-muted">${escapeHTML(c.email)}</span>
            <span class="s" style="font-size:12px;color:var(--muted)">${escapeHTML(c.phone)}</span>
          </div>
        </td>
        <td class="cell-muted">${escapeHTML(c.service)}</td>
        <td>${customerBadge(c.status)}</td>
        <td class="cell-muted">${fmt.date(c.joinedOn)}</td>
        <td class="right num" style="font-weight:600">${c.totalBilled ? fmt.inr(c.totalBilled) : "—"}</td>
      </tr>`).join("");
  }

  /* ---------- Events: search & filter ---------- */
  let debounce;
  searchInput.addEventListener("input", () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => {
      state.query = searchInput.value.trim();
      const url = new URL(window.location);
      state.query ? url.searchParams.set("q", state.query) : url.searchParams.delete("q");
      history.replaceState(null, "", url);
      render();
    }, 150);
  });

  // Top bar search stays on this page instead of reloading
  window.onGlobalSearch = (q) => {
    state.query = q;
    searchInput.value = q;
    render();
  };

  filterEl.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-status]");
    if (!btn) return;
    state.status = btn.dataset.status;
    render();
  });

  /* ---------- Customer details ---------- */
  function openDetails(id) {
    const c = Store.getCustomer(id);
    if (!c) return;
    const reqs = Store.getRequestsFor(c.id).sort((a, b) => b.requestedOn.localeCompare(a.requestedOn));

    document.getElementById("detailHero").innerHTML = `
      <div class="avatar avatar-lg" style="background:${avatarColor(c.name)}">${initials(c.name)}</div>
      <div>
        <h2 id="detailName">${escapeHTML(c.name)}</h2>
        <div class="sub">${escapeHTML(c.company)}<span style="margin-left:10px">${customerBadge(c.status)}</span></div>
      </div>`;

    const item = (label, value) => `<div><dt>${label}</dt><dd>${value}</dd></div>`;
    document.getElementById("detailBody").innerHTML = `
      <dl class="detail-grid" style="margin-top:0">
        ${item("Customer ID", escapeHTML(c.id))}
        ${item("Email", `<a href="mailto:${escapeHTML(c.email)}">${escapeHTML(c.email)}</a>`)}
        ${item("Phone", `<a href="tel:${escapeHTML(c.phone.replace(/\s/g, ""))}">${escapeHTML(c.phone)}</a>`)}
        ${item("Service", escapeHTML(c.service))}
        ${item("City", escapeHTML(c.city || "—"))}
        ${item("Customer since", fmt.date(c.joinedOn))}
        ${item("Total billed", `<span class="num">${fmt.inr(c.totalBilled)}</span>`)}
        ${item("Open requests", reqs.filter(r => r.status === "Pending" || r.status === "In progress").length)}
        ${item("All requests", reqs.length)}
      </dl>

      <div class="detail-section">
        <h3>Service requests</h3>
        <div class="mini-list">
          ${reqs.length ? reqs.map(r => `
            <div class="row">
              <div class="grow">
                <div class="t">${escapeHTML(r.title)}</div>
                <div class="s"><span class="mono-id">${r.id}</span><span style="margin-left:8px">Requested ${fmt.date(r.requestedOn)}</span></div>
              </div>
              ${priorityBadge(r.priority)}
              ${requestBadge(r.status)}
            </div>`).join("")
          : `<div class="none">This customer hasn't raised any service requests.</div>`}
        </div>
      </div>

      <div class="detail-section">
        <h3>Notes</h3>
        <div class="notes">${c.notes ? escapeHTML(c.notes) : "No notes added."}</div>
      </div>`;

    const mail = document.getElementById("detailEmail");
    mail.href = "mailto:" + c.email;
    mail.innerHTML = ICONS.mail + "Email customer";

    Modal.open("detailModal");
  }

  body.addEventListener("click", (e) => {
    const row = e.target.closest("tr[data-id]");
    if (row) openDetails(row.dataset.id);
  });
  body.addEventListener("keydown", (e) => {
    const row = e.target.closest("tr[data-id]");
    if (row && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); openDetails(row.dataset.id); }
  });

  /* ---------- Add customer ---------- */
  const form = document.getElementById("addForm");
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const PHONE_RE = /^\+?[0-9\s-]{10,15}$/;

  function openAdd() {
    form.reset();
    form.querySelectorAll(".field").forEach(f => f.classList.remove("has-error"));
    Modal.open("addModal");
  }
  document.getElementById("addCustomerBtn").addEventListener("click", openAdd);

  function setFieldError(name, message) {
    const field = form.querySelector(`.field[data-for="${name}"]`);
    field.classList.toggle("has-error", Boolean(message));
    field.querySelector(".field-error").textContent = message || "";
  }

  form.addEventListener("input", (e) => {
    const field = e.target.closest(".field");
    if (field) setFieldError(field.dataset.for, "");
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    Object.keys(data).forEach(k => data[k] = String(data[k]).trim());

    const errors = {};
    if (!data.name) errors.name = "Enter the customer's name.";
    else if (data.name.length < 2) errors.name = "Name must be at least 2 characters.";
    if (!data.company) errors.company = "Enter the company name.";
    if (!data.email) errors.email = "Enter an email address.";
    else if (!EMAIL_RE.test(data.email)) errors.email = "Enter a valid email, like name@company.com.";
    else if (Store.getCustomers().some(c => c.email.toLowerCase() === data.email.toLowerCase()))
      errors.email = "A customer with this email already exists.";
    if (!data.phone) errors.phone = "Enter a phone number.";
    else if (!PHONE_RE.test(data.phone)) errors.phone = "Enter a valid phone number (10–15 digits).";
    if (!data.service) errors.service = "Choose a service.";

    ["name", "company", "email", "phone", "service"].forEach(k => setFieldError(k, errors[k]));
    if (Object.keys(errors).length) {
      form.querySelector(".has-error input, .has-error select")?.focus();
      return;
    }

    const created = Store.addCustomer(data);
    Modal.close("addModal");
    state.query = ""; state.status = "All"; searchInput.value = "";
    render();
    Layout.refreshCounts();
    toast(`${created.name} added to customers`);
  });

  /* ---------- Initial render ---------- */
  render();

  // Deep links: ?id=CUS-1001 opens details, ?new=1 opens the add form
  const deepId = getQueryParam("id");
  if (deepId) openDetails(deepId);
  if (getQueryParam("new")) openAdd();
})();
