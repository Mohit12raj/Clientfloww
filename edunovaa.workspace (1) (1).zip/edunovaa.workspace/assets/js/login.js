/* ==========================================================
   Edunovaa Workspace — Login page logic
   Basic client-side validation, no backend.
   ========================================================== */
(function () {
  Auth.redirectIfSignedIn();

  const form       = document.getElementById("loginForm");
  const email      = document.getElementById("email");
  const password   = document.getElementById("password");
  const remember   = document.getElementById("remember");
  const alertBox   = document.getElementById("formAlert");
  const loginBtn   = document.getElementById("loginBtn");
  const pwToggle   = document.getElementById("pwToggle");

  // Brand panel points
  const points = [
    "Customer list with search and status filters",
    "Live summary of active services and pending requests",
    "Revenue at a glance, in rupees"
  ];
  document.getElementById("authPoints").innerHTML =
    points.map(p => `<li>${ICONS.check}<span>${p}</span></li>`).join("");

  // Show / hide password
  pwToggle.innerHTML = ICONS.eye;
  pwToggle.addEventListener("click", () => {
    const show = password.type === "password";
    password.type = show ? "text" : "password";
    pwToggle.innerHTML = show ? ICONS.eyeOff : ICONS.eye;
    pwToggle.setAttribute("aria-label", show ? "Hide password" : "Show password");
  });

  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function setError(fieldId, errorId, message) {
    const field = document.getElementById(fieldId);
    document.getElementById(errorId).textContent = message || "";
    field.classList.toggle("has-error", Boolean(message));
    field.querySelector("input").setAttribute("aria-invalid", message ? "true" : "false");
  }

  function validate() {
    let ok = true;
    const e = email.value.trim();
    const p = password.value;

    if (!e) { setError("emailField", "emailError", "Enter your email address."); ok = false; }
    else if (!EMAIL_RE.test(e)) { setError("emailField", "emailError", "Enter a valid email, like name@company.com."); ok = false; }
    else setError("emailField", "emailError", "");

    if (!p) { setError("passwordField", "passwordError", "Enter your password."); ok = false; }
    else if (p.length < 6) { setError("passwordField", "passwordError", "Password must be at least 6 characters."); ok = false; }
    else setError("passwordField", "passwordError", "");

    return ok;
  }

  function showAlert(message) {
    alertBox.innerHTML = ICONS.alert + `<span>${escapeHTML(message)}</span>`;
    alertBox.classList.toggle("show", Boolean(message));
  }

  // Clear errors while typing
  email.addEventListener("input", () => { setError("emailField", "emailError", ""); showAlert(""); });
  password.addEventListener("input", () => { setError("passwordField", "passwordError", ""); showAlert(""); });

  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    showAlert("");
    if (!validate()) {
      form.querySelector(".has-error input")?.focus();
      return;
    }

    loginBtn.disabled = true;
    loginBtn.innerHTML = `<span class="spinner"></span> Signing in…`;

    // Small delay so the loading state is visible (simulated request)
    setTimeout(() => {
      const result = Auth.login(email.value, password.value, remember.checked);
      if (result.ok) {
        window.location.replace("dashboard.html");
      } else {
        loginBtn.disabled = false;
        loginBtn.textContent = "Sign in";
        showAlert(result.message);
        password.select();
      }
    }, 600);
  });

  document.getElementById("fillDemo").addEventListener("click", () => {
    email.value = Auth.DEMO_USER.email;
    password.value = Auth.DEMO_USER.password;
    setError("emailField", "emailError", "");
    setError("passwordField", "passwordError", "");
    showAlert("");
    loginBtn.focus();
  });

  document.getElementById("forgotLink").addEventListener("click", (e) => {
    e.preventDefault();
    showAlert("Password reset isn't available in this version. Contact your workspace administrator.");
  });
})();
