/* ==========================================================
   Edunovaa Workspace — Mock data (no backend / no API)
   All data lives in plain JS objects. Customers added from
   the UI are kept in localStorage so they survive a refresh.
   ========================================================== */

const SERVICES = [
  "Website Development",
  "Mobile App Development",
  "SEO & Digital Marketing",
  "Cloud Hosting",
  "IT Support (AMC)",
  "LMS Setup"
];

const CUSTOMER_STATUSES = ["Active", "Pending", "Inactive"];

const SEED_CUSTOMERS = [
  { id: "CUS-1001", name: "Aarav Sharma",   company: "BrightPath Academy",     email: "aarav@brightpath.in",      phone: "+91 98110 23456", city: "New Delhi",  service: "LMS Setup",               status: "Active",   joinedOn: "2026-01-12", totalBilled: 185000, notes: "Runs 3 coaching centres. Wants student login on mobile." },
  { id: "CUS-1002", name: "Priya Nair",     company: "Nair Dental Clinic",     email: "priya@nairdental.com",     phone: "+91 98470 11223", city: "Kochi",      service: "Website Development",     status: "Active",   joinedOn: "2026-02-03", totalBilled: 64000,  notes: "Needs online appointment booking in phase 2." },
  { id: "CUS-1003", name: "Rohan Mehta",    company: "Mehta Logistics",        email: "rohan@mehtalogistics.in",  phone: "+91 99200 45671", city: "Mumbai",     service: "Cloud Hosting",           status: "Active",   joinedOn: "2026-02-19", totalBilled: 142500, notes: "" },
  { id: "CUS-1004", name: "Sneha Iyer",     company: "Kalaa Boutique",         email: "sneha@kalaa.store",        phone: "+91 98840 77812", city: "Chennai",    service: "SEO & Digital Marketing", status: "Pending",  joinedOn: "2026-09-18", totalBilled: 0,      notes: "Proposal shared. Waiting for sign-off." },
  { id: "CUS-1005", name: "Vikram Singh",   company: "Singh Motors",           email: "vikram@singhmotors.co.in", phone: "+91 98150 33445", city: "Ludhiana",   service: "IT Support (AMC)",        status: "Active",   joinedOn: "2026-03-07", totalBilled: 96000,  notes: "Annual contract, 4 branches." },
  { id: "CUS-1006", name: "Ananya Gupta",   company: "Little Sprouts School",  email: "ananya@littlesprouts.edu.in", phone: "+91 97170 66554", city: "Noida",   service: "LMS Setup",               status: "Active",   joinedOn: "2026-04-15", totalBilled: 210000, notes: "" },
  { id: "CUS-1007", name: "Karan Malhotra", company: "UrbanNest Realty",       email: "karan@urbannest.in",       phone: "+91 98730 90011", city: "Gurugram",   service: "Mobile App Development",  status: "Pending",  joinedOn: "2026-09-22", totalBilled: 0,      notes: "Requested a quote for Android + iOS." },
  { id: "CUS-1008", name: "Meera Joshi",    company: "Joshi & Associates",     email: "meera@joshiassociates.in", phone: "+91 98220 14789", city: "Pune",       service: "Website Development",     status: "Inactive", joinedOn: "2025-11-28", totalBilled: 48000,  notes: "Project delivered. Contract ended in June." },
  { id: "CUS-1009", name: "Arjun Reddy",    company: "FreshCart Grocers",      email: "arjun@freshcart.in",       phone: "+91 98490 55120", city: "Hyderabad",  service: "Mobile App Development",  status: "Active",   joinedOn: "2026-05-09", totalBilled: 325000, notes: "Delivery app live. Maintenance ongoing." },
  { id: "CUS-1010", name: "Ishita Banerjee", company: "Rang Design Studio",    email: "ishita@rangstudio.in",     phone: "+91 98300 22871", city: "Kolkata",    service: "SEO & Digital Marketing", status: "Active",   joinedOn: "2026-06-21", totalBilled: 72000,  notes: "" },
  { id: "CUS-1011", name: "Rahul Verma",    company: "Verma Pharma Distributors", email: "rahul@vermapharma.in",  phone: "+91 94150 88213", city: "Lucknow",    service: "Cloud Hosting",           status: "Inactive", joinedOn: "2025-10-04", totalBilled: 38000,  notes: "Moved hosting in-house." },
  { id: "CUS-1012", name: "Neha Kapoor",    company: "FitLife Studios",        email: "neha@fitlife.studio",      phone: "+91 99100 67342", city: "New Delhi",  service: "Website Development",     status: "Active",   joinedOn: "2026-07-30", totalBilled: 56000,  notes: "Membership page to be added." },
  { id: "CUS-1013", name: "Siddharth Rao",  company: "Rao Engineering Works",  email: "sid@raoengg.com",          phone: "+91 98450 31190", city: "Bengaluru",  service: "IT Support (AMC)",        status: "Pending",  joinedOn: "2026-09-25", totalBilled: 0,      notes: "Site survey scheduled." },
  { id: "CUS-1014", name: "Pooja Deshmukh", company: "Deshmukh Tutorials",     email: "pooja@deshmukhtutorials.in", phone: "+91 98600 72215", city: "Nagpur",   service: "LMS Setup",               status: "Active",   joinedOn: "2026-08-11", totalBilled: 118000, notes: "" }
];

const SERVICE_REQUESTS = [
  { id: "SR-2058", customerId: "CUS-1013", service: "IT Support (AMC)",        title: "Network audit for new office",   requestedOn: "2026-09-27", priority: "High",   status: "Pending",     amount: 45000 },
  { id: "SR-2057", customerId: "CUS-1007", service: "Mobile App Development",  title: "Quote: property listing app",    requestedOn: "2026-09-26", priority: "Medium", status: "Pending",     amount: 280000 },
  { id: "SR-2056", customerId: "CUS-1001", service: "LMS Setup",               title: "Add batch-wise attendance",      requestedOn: "2026-09-25", priority: "Medium", status: "In progress", amount: 22000 },
  { id: "SR-2055", customerId: "CUS-1009", service: "Mobile App Development",  title: "Fix payment gateway timeout",    requestedOn: "2026-09-24", priority: "High",   status: "In progress", amount: 15000 },
  { id: "SR-2054", customerId: "CUS-1004", service: "SEO & Digital Marketing", title: "Instagram campaign — Diwali",    requestedOn: "2026-09-23", priority: "Medium", status: "Pending",     amount: 36000 },
  { id: "SR-2053", customerId: "CUS-1002", service: "Website Development",     title: "Online appointment booking",     requestedOn: "2026-09-21", priority: "Low",    status: "Pending",     amount: 28000 },
  { id: "SR-2052", customerId: "CUS-1005", service: "IT Support (AMC)",        title: "Replace router at Branch 3",     requestedOn: "2026-09-19", priority: "High",   status: "Completed",   amount: 8500 },
  { id: "SR-2051", customerId: "CUS-1012", service: "Website Development",     title: "Membership page",                requestedOn: "2026-09-17", priority: "Medium", status: "In progress", amount: 18000 },
  { id: "SR-2050", customerId: "CUS-1006", service: "LMS Setup",               title: "Parent login module",            requestedOn: "2026-09-14", priority: "Medium", status: "Completed",   amount: 40000 },
  { id: "SR-2049", customerId: "CUS-1003", service: "Cloud Hosting",           title: "Increase server storage",        requestedOn: "2026-09-10", priority: "Low",    status: "Completed",   amount: 12000 },
  { id: "SR-2048", customerId: "CUS-1010", service: "SEO & Digital Marketing", title: "Monthly SEO report",             requestedOn: "2026-09-06", priority: "Low",    status: "Completed",   amount: 9000 },
  { id: "SR-2047", customerId: "CUS-1008", service: "Website Development",     title: "Domain renewal",                 requestedOn: "2026-09-02", priority: "Low",    status: "Cancelled",   amount: 0 }
];

/* ---------- Simple data store ---------- */
const Store = (() => {
  const KEY = "ew_customers_added";

  function readAdded() {
    try { return JSON.parse(localStorage.getItem(KEY) || "[]"); }
    catch (e) { return []; }
  }

  return {
    getCustomers() {
      return [...readAdded(), ...SEED_CUSTOMERS];
    },
    getCustomer(id) {
      return this.getCustomers().find(c => c.id === id) || null;
    },
    addCustomer(data) {
      const all = this.getCustomers();
      const maxId = all.reduce((m, c) => Math.max(m, parseInt(c.id.split("-")[1], 10) || 0), 1000);
      const customer = {
        id: "CUS-" + (maxId + 1),
        totalBilled: 0,
        joinedOn: new Date().toISOString().slice(0, 10),
        notes: "",
        ...data
      };
      const added = readAdded();
      added.unshift(customer);
      try { localStorage.setItem(KEY, JSON.stringify(added)); } catch (e) { /* storage unavailable: keep in memory only */ }
      return customer;
    },
    getRequests() {
      return SERVICE_REQUESTS.slice();
    },
    getRequestsFor(customerId) {
      return SERVICE_REQUESTS.filter(r => r.customerId === customerId);
    },
    resetDemoData() {
      try { localStorage.removeItem(KEY); } catch (e) {}
    }
  };
})();
